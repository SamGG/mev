###################################################
### chunk number 1: 
###################################################

library(minet)

data(syn.data)
#Mutual information estimation
estimator="spearman"
mim <- build.mim(syn.data,estimator)
mim[1:5,1:5]


###################################################
### chunk number 2: 
###################################################
#Network Inference
net <- mrnet(mim)
net[1:5,1:5]


###################################################
### chunk number 3: 
###################################################
library(minet)
data(syn.data)
net <- minet(syn.data, 
             method="mrnet")
net[1:5,1:5]


###################################################
### chunk number 4: 
###################################################
library(minet)
data(syn.data)
data(syn.net)
net <- minet(syn.data)
#Infered network validation
table <- validate(net, syn.net, steps=20)
table[1:10,]


###################################################
### chunk number 5: 
###################################################
library(minet)
data(syn.data)
data(syn.net)
net1 <- minet(syn.data,method="mrnet")
net2 <- minet(syn.data,method="clr")
#Infered network validation
table1 <- validate(net1, syn.net, steps=50)
table2 <- validate(net2, syn.net, steps=50)


###################################################
### chunk number 6: 
###################################################
#Precision recall curves
dev <- show.pr( table1, pch=2, type="b", col="green" )
show.pr( table2, device=dev, pch=1, type="b", col="blue")
#ROC curves
dev <- show.roc( table1, type="b", col="green" )
show.roc( table2,device=dev,type="b",col="blue" )



### Name: build.mim
### Title: Build Mutual Information Matrix
### Aliases: build.mim
### Keywords: misc

### ** Examples

  data(syn.data)
  mim <- build.mim(syn.data,estimator="spearman")




### Name: syn.data
### Title: Simulated Gene Expression Data
### Aliases: syn.data
### Keywords: datasets

### ** Examples


data(syn.data)
data(syn.net)
mim <- build.mim(syn.data,estimator="spearman")
infered.net <- mrnet(mim)
max(fscores(validate( infered.net, syn.net )))




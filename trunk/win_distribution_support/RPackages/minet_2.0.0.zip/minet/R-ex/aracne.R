### Name: aracne
### Title: Algorithm for the Reconstruction of Accurate Cellular NEtworks
### Aliases: aracne
### Keywords: misc

### ** Examples

data(syn.data)
mim <- build.mim(syn.data,estimator="spearman")
net <- aracne(mim)




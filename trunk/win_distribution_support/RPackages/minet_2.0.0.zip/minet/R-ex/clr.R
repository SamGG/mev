### Name: clr
### Title: Context Likelihood or Relatedness Network
### Aliases: clr
### Keywords: misc

### ** Examples

data(syn.data)
mim <- build.mim(syn.data,estimator="spearman")
net <- clr(mim)




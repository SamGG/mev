### Name: mrnet
### Title: Maximum Relevance Minimum Redundancy
### Aliases: mrnet
### Keywords: misc

### ** Examples

data(syn.data)
mim <- build.mim(syn.data, estimator="spearman")
net <- mrnet(mim)




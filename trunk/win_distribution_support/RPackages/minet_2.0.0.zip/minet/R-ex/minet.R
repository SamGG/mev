### Name: minet
### Title: Mutual Information Network
### Aliases: minet
### Keywords: misc

### ** Examples

data(syn.data)
net1 <- minet( syn.data )
net2 <- minet( syn.data, estimator="pearson" )
net3 <- minet( syn.data, method="clr", estimator="spearman" )




### Name: validate
### Title: Inference Validation
### Aliases: validate
### Keywords: misc

### ** Examples

data(syn.data)
data(syn.net)
inf.net <- mrnet(build.mim(syn.data, estimator="spearman"))
table <- validate( inf.net, syn.net, steps=100 )
table <- validate( inf.net, syn.net, steps=1, thresholds=0.5 )




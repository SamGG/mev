### Name: multiinformation
### Title: multiinformation computation
### Aliases: multiinformation
### Keywords: misc

### ** Examples

  data(USArrests)
  dat<-discretize(USArrests)
  M <- multiinformation(dat)




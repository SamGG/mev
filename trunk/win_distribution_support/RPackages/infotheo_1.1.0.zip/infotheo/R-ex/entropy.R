### Name: entropy
### Title: entropy computation
### Aliases: entropy
### Keywords: misc

### ** Examples

  data(USArrests)
  H <- entropy(discretize(USArrests),method="shrink")




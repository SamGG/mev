### Name: khanmiss
### Title: Khan microarray data with random missing values
### Aliases: khanmiss
### Keywords: datasets

### ** Examples

  data(khanmiss)



